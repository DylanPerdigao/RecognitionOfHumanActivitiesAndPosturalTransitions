% load data_users
for i = 1:10
   represent_grafica(data{i}, "data"); 
end